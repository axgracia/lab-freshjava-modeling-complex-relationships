package com.ironhacklab.Modeling.Relationships;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ModelingRelationshipsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ModelingRelationshipsApplication.class, args);
	}

}
