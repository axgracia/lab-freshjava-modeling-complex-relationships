package com.ironhacklab.Modeling.Relationships;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ModelingRelationshipsApplicationTests {

	@Test
	void contextLoads() {
	}

}
